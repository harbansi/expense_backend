const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const BudgetSchema = new Schema({
  title: {
    type: String,
    required: true,
    unique: true,
  },
  amount: {
    type: Number,
    required: true,
  },
  expense: [
    {
      category: {
        label: {
          type: String,
          required: false,
          unique: true,
        },
      },
      categories: [
        {
          label: {
            type: String,
            required: true,
            unique: true,
          },
          amount: {
            type: Number,
            required: true,
          },
        },
      ],
    },
  ],
});

const Budget = mongoose.model("Budget", BudgetSchema);

module.exports = Budget;
